﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Models;

namespace WpfApp1.DataWindows
{
    /// <summary>
    /// Логика взаимодействия для AppDataWindow.xaml
    /// </summary>
    public partial class AppDataWindow : Window
    {
        Executor exec;
        string CurrentTable;

        public AppDataWindow(Executor exec)
        {
            InitializeComponent();
            this.exec = exec;
        }

        public void LoadData(object sender, RoutedEventArgs e)
        {
            List<object> items = new List<object>();

            using (var db = new MobileContext()) {
                if ((sender as MenuItem).Header.ToString() == "Заявки") { foreach (var el in db.Apps) { items.Add(el); } }
                else if ((sender as MenuItem).Header.ToString() == "Клиенты") { foreach (var el in db.Clients) { items.Add(el); } }
                else if ((sender as MenuItem).Header.ToString() == "Категории") { foreach (var el in db.Categories) { items.Add(el); } }
                else if ((sender as MenuItem).Header.ToString() == "Исполнители") { foreach (var el in db.Executors) { items.Add(el); } }
                else if ((sender as MenuItem).Header.ToString() == "История") { foreach (var el in db.Histories) { items.Add(el); } }

                CurrentTable = (sender as MenuItem).Header.ToString();
            }

            DataTable.ItemsSource = items;
            
        }

        public void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            var win = new Window2(this.exec);
            win.Show();
            this.Close();
        }

        public void UpdateBtn_Click(object sender, RoutedEventArgs e)
        {

        }

        public void DeleteBtn_Click(object sender, RoutedEventArgs e)
        {
            var selected = DataTable.SelectedItem;
            var result = MessageBox.Show(
                    "Вы уверены, что хотите выполнить удаление выбранного объекта?",
                    "Удаление",
                    MessageBoxButton.YesNo
                );
            if (result == MessageBoxResult.Yes)
            {
                using (var db = new MobileContext())
                {
                    if (CurrentTable == "Заявки") { db.Apps.Remove(selected as Models.App); }
                    else if (CurrentTable == "Клиенты") { db.Clients.Remove(selected as Client); }
                    else if (CurrentTable == "Категории") { db.Categories.Remove(selected as Category); }
                    else if (CurrentTable == "Исполнители") { db.Executors.Remove(selected as Executor); }
                    else if (CurrentTable == "История") { db.Histories.Remove(selected as History); }

                    db.SaveChanges();
                    DataTable.Items.Remove(selected);
                }
                MessageBox.Show("Удаление завершено");
            }
        }
    }
}
