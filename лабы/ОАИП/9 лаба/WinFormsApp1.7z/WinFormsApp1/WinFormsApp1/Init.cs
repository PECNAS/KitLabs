﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    public static class Init
    {
        public static Bitmap bitmap;
        public static PictureBox pb;
        public static Pen pen;

        public static int pbh;
        public static int pbw;
    }
}
