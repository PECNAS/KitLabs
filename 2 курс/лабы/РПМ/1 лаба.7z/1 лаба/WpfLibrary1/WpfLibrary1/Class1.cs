
namespace WpfLibrary1
{
    public class Class1
    {
    }

}
