﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10
{
    internal class AnalInfo
    {
        public int count = 0;
        public int comparisons = 0;
        public int permutations = 0;
        public string time = "";
    }
}
