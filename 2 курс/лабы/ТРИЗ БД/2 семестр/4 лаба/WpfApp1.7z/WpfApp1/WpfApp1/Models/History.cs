﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Models
{
    public class History
    {
        public int Id { get; set; }
        public int AppId { get; set; }
        public int ExecId { get; set; }

    }
}
